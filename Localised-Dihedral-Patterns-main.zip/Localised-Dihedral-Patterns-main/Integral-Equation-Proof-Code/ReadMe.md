Integral Equation Proof Code to show a C0 solution exists for 
a(t) = 2*int_0^{1-t} a(t)*a(t+s)ds + int_0^t a(s)a(t-s) ds

To run code:
1. Initialise IntLab:
https://www.tuhh.de/ti3/rump/intlab/
2. Run script Integral_Matching_Eqn_Proof_Clean.m
